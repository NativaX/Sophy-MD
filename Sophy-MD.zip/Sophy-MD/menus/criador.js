exports.donor = (comando, prefix, hora, data, pushname) => {
return `
╭━─━───༺[👑]༻────━─━╮
┃[☆]╭
┃[☆] ⎙ INFORMAÇÕES DO DONO
┃[☆]╰
╰━─━───༺[👑]༻────━─━╯
┏━━━━━━━━ ✓
┃[☆] -➤ Cntt: Wa.me/+558391780744
┃[☆] -➤ Insta: instagram.com/nk.nativa
┗━━━━━━━━ ✓
┏━━━━━━━━ ✓
┃[☆] -➤ Prefixo : [ ${prefix} ]
┃[☆] -➤ Bot: ${botName}
┗━━━━━━━━ ✓
`
 }