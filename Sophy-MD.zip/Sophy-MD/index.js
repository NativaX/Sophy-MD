//｡☆✼★━━━━━━ATENÇÃO━━━━━━━━━━★✼☆｡
//Base Totalmente Editada Pelo Nativa, Caso tenha alguma Dúvida Entre em Contato Comigo!! 
//NÚMERO: +55 83 99178-0744
//NOME: NATIVAX
//｡☆✼★━━━━━━ATENÇÃO━━━━━━━━━━★✼☆｡
require("./config.js")


const { 
default:
makeWASocket, 
downloadContentFromMessage,
generateWAMessageContent,
generateWAMessageFromContent,
StylePrivWaFromMessage,
delay,
useMultiFileAuthState,
BufferJSON,
proto,
close,
prepareWAMessageMedia, 
MediaType,
ChatModification,
DisconnectReason,
relayWAMessage,
fetchLatestBaileysVersion,
WASocket,
Browsers,
EyeWaSocket,
makeInMemoryStore,
} = require('@WhiskeySockets/baileys');
require('@adiwajshing/baileys')

// ──────┤MODULOS├──────//

const { getRandom} = require('./arquivos/funções/myfunc.js');

const { exec } = require("child_process")

const chalk = require('chalk');

const { runtime } = require("./arquivos/myfunc")

const color = (text, color) => { return !color ? chalk.green(text) : chalk.keyword(color)(text) };

let pino = require('pino')

const fs = require('fs')

const axios = require('axios');

const util = require("util")

const path = require("path")

const fetch = require('node-fetch');

const speed = require('performance-now')

const moment = require('moment-timezone');

const ffmpeg = require('fluent-ffmpeg');

const mimetype = require("mime-types")

const BodyForm = require("form-data");

const { Boom }  = require('@hapi/boom');

const yts = require('yt-search');

const crypto = require('crypto');

const encodeUrl = require('encodeurl');

const cheerio = require('cheerio');

const { Configuration, OpenAIApi } = require("openai");

const { menu } = require('./menus/menu.js')

const { donor } = require('./menus/criador.js')

const registros = JSON.parse(fs.readFileSync('./arquivos/registros.json'));

//COLOQUE AS API AKI

const API_KEY_SABRINA = "api-do_flexa"
const API_KEY_NATIVA = "NATIVA123";

//ARQUIVOS JS
const { getGroupAdmins, banner } = require('./sophy/browser/browser.js');
const { 
getExtension, Random, 
getFileBuffer, getBuffer,
} = require("./sophy/browser/get.js")
const { fetchJson } = require('./arquivos/funções.js');
const { addFlod , isFlod } = require('./spam.js')
const { isFiltered, addFilter } = require('./spam.js')
const { palavras } = require('./arquivos/lib/conselhos.js');

//ARQUIVOS DA CONFIG PREFIX DONO E NOME BOT CASO NÃO SAIBA MEXE NÃO MEXA NISSO DEIXA ASSIM OU VAI CAUSAR ERRO
donoName = global.donoName
botName = global.botName
donoNumher = global.donoNumher
prefix = global.prefix

// IGNORE //
function kyun(seconds){
function pad(s){ return (s < 10 ? '0' : '') + s;}
var hours = Math.floor(seconds / (60*60));
var minutes = Math.floor(seconds % (60*60) / 60);
var seconds = Math.floor(seconds % 60);return `${pad(hours)} times ${pad(minutes)} Minutos ${pad(seconds)} Segundos` }
const convertBytes = function(bytes) {
const sizes = ["Bytes", "KB", "MB", "GB", "TB"]
if (bytes == 0) {
return "n/a"
}
const i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)))
if (i == 0) {
return bytes + " " + sizes[i]
}
return (bytes / Math.pow(1024, i)).toFixed(1) + " " + sizes[i]
}

//DATE E TIME BY NATIVA_MODZ//

const time = moment().tz('America/Sao_Paulo').format('HH:mm:ss')

const date = moment.tz('America/Sao_Paulo').format('DD/MM/YY')

async function startActivity() {

// CONEXÃO DO BOT UAI
const store = makeInMemoryStore({ logger: pino().child({ level: 'debug', stream: 'store' }) })

const { state, saveCreds } = await useMultiFileAuthState('./sophyqr')

const { version, isLatest } = await fetchLatestBaileysVersion()


console.log(banner.string)
console.log((`                  ${botName} ATIVA\n
╭─────≽「‼️${botName}‼️」
│Criador: LK'Delas
│Bot: ${botName}
│Dono: ${donoName}
│date: ${date}
│time: ${time}
│Prefixo: [ ${prefix} ]
╰────────────────────────`))
const sophy = makeWASocket({
logger: pino({ level: 'silent'}),
printQRInTerminal: true,
qrTimeout: 180000,
browser: ['SOPHY-MD', 'browser', '1.0.0'],
auth: state
})
store.bind(sophy.ev)


sophy.ev.on('chats.set', () => {
console.log('setando conversas...')
})


sophy.ev.on('contacts.set', () => {
console.log('setando contatos...')
})

sophy.ev.on('creds.update', saveCreds)

sophy.ev.on('messages.upsert', async ({ messages }) => {
try {
//=============funções
const info = m = messages[0]
if (!info.message) return 

const key = {
    remoteJid: info.key.remoteJid,
    id: info.key.id, 
    participant: info.key.participant 
}
await sophy.readMessages([key])

if (info.key && info.key.remoteJid == 'status@broadcast') return
const altpdf = Object.keys(info.message)
const type = altpdf[0] == 'senderKeyDistributionMessage' ? altpdf[1] == 'messageContextInfo' ? altpdf[2] : altpdf[1] : altpdf[0]

type_message = JSON.stringify(info.message)

const isQuotedImage = type === "extendedTextMessage" && type_message.includes("imageMessage")
const from = m.chat = info.key.remoteJid

/// ==============budy
const budy = (type === 'conversation') ? info.message.conversation : (type === 'extendedTextMessage') ? info.message.extendedTextMessage.text : ''

///============body
var body = (type === 'conversation') ?
info.message.conversation : (type == 'imageMessage') ?
info.message.imageMessage.caption : (type == 'videoMessage') ?
info.message.videoMessage.caption : (type == 'extendedTextMessage') ?
info.message.extendedTextMessage.text : (type == 'buttonsResponseMessage') ?
info.message.buttonsResponseMessage.selectedButtonId : (info.message.listResponseMessage && info.message.listResponseMessage.singleSelectenviar.selectedRowId.startsWith(prefix) && info.message.listResponseMessage.singleSelectenviar.selectedRowId) ? info.message.listResponseMessage.singleSelectenviar.selectedRowId : (type == 'templateButtonenviarMessage') ?
info.message.templateButtonenviarMessage.selectedId : (type === 'messageContextInfo') ? (info.message.buttonsResponseMessage?.selectedButtonId || info.message.listResponseMessage?.singleSelectenviar.selectedRowId || info.text) : ''
////========
const content = JSON.stringify(info.message);

const isCmd = body.startsWith(prefix)

const isGroup = from.endsWith("@g.us")


// Render de Jogos
gayzin = gayzão
fein = feião 
matei = mateii
cornin = cornão
vesgin = vesgão
bebin = bebão
gadin = gadão
gostosin = gostosão
gostosinha = gostosona 
hitler = nazista
tapinha = tapão
beijin = beijão
chutin = chutão
dancinha = dança 
casalzin = casar
soquin = socão 
By = "SOPHY-MD OFC"

/////==================
const isUrl = (url) => {
	return url.match(new RegExp(/https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_+.~#?&/=]*)/, 'gi'))
			}
const sender = isGroup ? info.key.participant: from

const command = comando = isCmd ? body.slice(1).trim().split(/ +/).shift().toLocaleLowerCase() : null

const nome = pushName = info.pushName ? info.pushName: botName 

const pushname = info.pushName ? info.pushName : ""

const groupMetadata = isGroup ? await sophy. groupMetadata(from): ""

const participants = isGroup ? await groupMetadata.participants : ''

const groupName = isGroup  ? groupMetadata.subject: ""

const groupDesc = isGroup ? groupMetadata.desc : ''

const groupMembers = isGroup ? groupMetadata.participants : ''

const groupAdmins = isGroup ? getGroupAdmins(groupMembers) : ''

const args = body.trim().split(/ +/).splice(1)

const q = text = args.join(' ')

const criador = `${donoNumher}@s.whatsapp.net`

const numeroBot = sophy.user.id.split(":")[0]+"@s.whatsapp.net"

const isCreator = criador.includes(sender)

const isGroupAdmins = groupAdmins.includes(sender) || false 

const isBotAdmins = groupAdmins.includes(numeroBot) || false

const isBotGroupAdmins = groupAdmins.includes(numeroBot) || false

//********************************************//

const { mensagens } = require('./arquivos/funções/aleatoria.js');

var texto_exato = (type === 'conversation') ? info.message.conversation : (type === 'extendedTextMessage') ? info.message.extendedTextMessage.text : ''

var enviarmen = mensagens[Math.floor(Math.random() * mensagens.length)] 

const texto = texto_exato.slice(0).trim().split(/ +/).shift().toLowerCase()

async function escrever (texto) {
await sophy.sendPresenceUpdate('composing', from) 
await esperar(1000)   
sophy.sendMessage(from, { text: texto }, {quoted: contato})
}

const enviar = (texto) => {
sophy.sendMessage(from, { text: texto }, {quoted: contato})
}

const mandar = (texto) => {
sophy.sendMessage(from, { text: texto }, {quoted: info}).catch(e => {
console.log(e)
})
}

const min = JSON.parse(fs.readFileSync('./sophyedt/edite/fotos.json'))
megu = min.megumax

const reply = (texto) => {
mimi = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
sophy.sendMessage(from, {
document: fs.readFileSync('./arquivos/lib/arquivo.xlsx'),
mimetype: mimi,
jpegThumbnail: null,
mentions: null,
fileName: `${pushname}`,
fileLength: 9999999999999999999999999999,
caption: texto,
footer: `Usuario:${pushname}`, 
contextInfo:{"externalAdReply": {"title": `${botName}`,"body": `Dono: иαтινα`, "previewType": "PHOTO","thumbnailUrl": `${megu}`,"thumbnail":  Buffer,"sourceUrl": "https://wa.me/558391780744?text=Slv%20Nativa"}}}, { quoted: info})}

const esperar = sleep = async (tempo) => {
    return new Promise(funcao => setTimeout(funcao, tempo));
}

//================//isquoted/const
const isImage = type == 'imageMessage'
const isVideo = type == 'videoMessage'
const isAudio = type == 'audioMessage'
const isSticker = type == 'stickerMessage'
const isContact = type == 'contactMessage'
const isLocation = type == 'locationMessage'
const isProduct = type == 'productMessage'
const isMedia = (type === 'imageMessage' || type === 'videoMessage' || type === 'audioMessage')
typeMessage = body.substr(0, 50).replace(/\n/g, '')
if (isImage) typeMessage = "Image"
else if (isVideo) typeMessage = "Video"
else if (isAudio) typeMessage = "Audio"
else if (isSticker) typeMessage = "Sticker"
else if (isContact) typeMessage = "Contact"
else if (isLocation) typeMessage = "Location"
else if (isProduct) typeMessage = "Product"

var pes = (type === 'conversation' && info.message.conversation) ? info.message.conversation : (type == 'imageMessage') && info.message.imageMessage.caption ? info.message.imageMessage.caption : (type == 'videoMessage') && info.message.videoMessage.caption ? info.message.videoMessage.caption : (type == 'extendedTextMessage') && info.message.extendedTextMessage.text ? info.message.extendedTextMessage.text : ''

const isQuotedMsg = type === 'extendedTextMessage' && content.includes('textMessage')

const isQuotedVideo = type === 'extendedTextMessage' && content.includes('videoMessage')

const isQuotedDocument = type === 'extendedTextMessage' && content.includes('documentMessage')

const isQuotedAudio = type === 'extendedTextMessage' && content.includes('audioMessage')

const isQuotedSticker = type === 'extendedTextMessage' && content.includes('stickerMessage')

const isQuotedContact = type === 'extendedTextMessage' && content.includes('contactMessage')

const isQuotedLocation = type === 'extendedTextMessage' && content.includes('locationMessage')

const isQuotedProduct = type === 'extendedTextMessage' && content.includes('productMessage')
 
 const isRegistro = registros.includes(sender)
 
const messagesC = pes.slice(0).trim().split(/ +/).shift().toLowerCase()

const exportion = JSON.parse(fs.readFileSync('./exportion.json'))

const mentions = (teks, memberr, id) => {
(id == null || id == undefined || id == false) ? sophy.sendMessage(from, {text: teks.trim(), mentions: memberr}) : sophy.sendMessage(from, {text: teks.trim(), mentions: memberr})
}

// VERIFICADOS ⭐️

const contato = {key : {participant : '0@s.whatsapp.net'},message: {contactMessage:{displayName: `${pushname}`}}}

const imgm = {key : {participant : '0@s.whatsapp.net'},message: {imageMessage: {}}}

const vid = {key : {participant : '0@s.whatsapp.net'},message: {videoMessage: {}}}

const mus = {key : {participant : '0@s.whatsapp.net'},message: {audioMessage: {}}}

// ❗𝙲𝙾𝙼𝙰𝙽𝙳𝙾 𝙽𝙾 𝙿𝚅❗
if (!isGroup && isCmd) console.log(
color(' ❗𝙲𝙾𝙼𝙰𝙽𝙳𝙾 𝙽𝙾 𝙿𝚅❗','white'),'\n',
color('‣ ΝᏆᏟᏦ :','red'),color(pushname,'cyan'),'\n',
color('‣ ΝႮ́ᎷᎬᎡϴ :','red'),color(sender.split("@")[0],'blue'),'\n',
color('‣ ᏟᎷᎠ :','red'),color(command,'cyan'),'\n',
color('‣ ᎻϴᎡᎪ :','red'),color(time,'cyan'),'\n')

// ❗𝙼𝙴𝙽𝚂𝙰𝙶𝙴𝙼 𝙽𝙾 𝙿𝚅❗
if (!isCmd && !isGroup && !info.key.fromMe) console.log(
color('❗𝙼𝙴𝙽𝚂𝙰𝙶𝙴𝙼 𝙽𝙾 𝙿𝚅❗','white'),'\n',
color('‣ ΝႮ́ᎷᎬᎡϴ :','red'),color(sender.split("@")[0],'blue'),'\n',
color('‣ ΝᏆᏟᏦ :','red'),color(pushname,'cyan'),'\n',
color('‣ ᎻϴᎡᎪ :','red'),color(time,'cyan'),'\n')

// ❗𝙲𝙾𝙼𝙰𝙽𝙳𝙾 𝙴𝙼 𝙶𝚁𝚄𝙿𝙾❗
if (isCmd && isGroup) console.log(
color('❗𝙲𝙾𝙼𝙰𝙽𝙳𝙾 𝙴𝙼 𝙶𝚁𝚄𝙿𝙾❗','white'),'\n',
color('‣ ᏀᎡႮᏢϴ :','blue'),color(groupName,'yellow'),'\n',
color('‣ ΝႮ́ᎷᎬᎡϴ :','blue'),color(sender.split("@")[0],'red'),'\n',
color('‣ ΝᏆᏟᏦ :','blue'),color(pushname,'yellow'),'\n',
color('‣ ᏟᎷᎠ :','blue'),color(command,'yellow'),'\n',
color('‣ ᎻϴᎡᎪ :','blue'),color(time,'yellow'),'\n')

// ❗𝙼𝙴𝙽𝚂𝙰𝙶𝙴𝙼 𝙴𝙼 𝙶𝚁𝚄𝙿𝙾❗
if (!isCmd && isGroup && !info.key.fromMe) console.log(
color('❗𝙼𝙴𝙽𝚂𝙰𝙶𝙴𝙼 𝙴𝙼 𝙶𝚁𝚄𝙿𝙾❗','white'),'\n',
color('‣ ᏀᎡႮᏢϴ :','blue'),color(groupName,'cyan'),'\n',
color('‣ ΝႮ́ᎷᎬᎡϴ :','blue'),color(sender.split("@")[0],'red'),'\n',
color('‣ ΝᏆᏟᏦ :','blue'),color(pushname,'cyan'),'\n',
color('‣ ᎻϴᎡᎪ :','blue'),color(time,'cyan'),'\n')


//
msg = {
botadm: "[❗] bot precisa ser adm",
aguarde: "[❗] aguarde uns minutinho estou processado👨‍🦯",
dono: "[❗] este comando so podera ser usado pelo meu dono💣",
grupo: "[❗] este comando so pode ser usado em grupo🫂",
private: "[❗] este comando so pode ser usado no privado👀",
adm: "[❗] este comando so pode ser usado por um adm",
botadm: "[❗] bot precisa ser adm pra executar esse comando",
error: "[❗] ocorreu uma falha no comando por favor aguarde ate meu dono ajeitar", 
dono: "[❗] Esse comando so pode ser usado pelo meu dono!!!",
}

//INÍCIO DOS COMANDOS BY NATIVA
switch(comando) {


//_______________CASE REGISTRAR_______________//

case 'login':
await reply(`𓆩Registrando Dados, Aguarde𓆪`)
registros.push(sender)
fs.writeFileSync("./arquivos/registros.json", JSON.stringify(registros))

pxz = `
╭───∘⟬𝐒𝐄𝐔 𝐑𝐄𝐆𝐈𝐒𝐓𝐑𝐎⟭∘───⪨
│
│𝐍𝐎𝐌𝐄: ${pushname}
│
│𝐍𝐔́𝐌𝐄𝐑𝐎: ${sender.split("@")[0]}
│
│𝐃𝐀𝐓𝐀: ${date}
│
│𝐇𝐎𝐑𝐀: ${time}
│
╰───────────────────⪨
`
await sleep(10000)
sophy.sendMessage(from, {image: {url:
'https://telegra.ph/file/fd87583a983f686f4fe03.jpg' }, caption: pxz, mentions:
[sender]}, {quoted: info })
break


//_______________PUXADA DOS MENUS_______________//

case 'menu':
if(!isRegistro) return reply(`Use: ${prefix}Login Para se Registrar no Bot`)
await sophy.sendMessage(from, { react: { text: `💜`, key: info.key }})
sophy.sendMessage(from,
{image: fs.readFileSync('./sophy/image/menu.jpg'),
caption: menu(comando, prefix, time, date, pushname),
gifPlayback: true},
{quoted: contato})
break


case 'criador':
if(!isRegistro) return reply(`Use: ${prefix}Login Para se Registrar no Bot`)
await sophy.sendMessage(from, { react: { text: `👑`, key: info.key }})
sophy.sendMessage(from,
{image: fs.readFileSync('./sophy/image/menu.jpg'),
caption: donor(comando, prefix, time, date, pushname),
gifPlayback: true},
{quoted: contato})
break


//_______________COMANDOS ADM_______________//

case 'ban':
if(!isRegistro) return reply(`Use: ${prefix}Login Para se Registrar no Bot`)
if (!isGroup) return reply('Comando só Pode ser Usado em Grupo!')
if (!isBotAdmins) return enviar('Preciso ser ADM para Realizar essa Ação!')
if (!isGroupAdmins) return enviar('Você não é Um Administrador!')
{
if (info.message.extendedTextMessage === undefined || info.message.extendedTextMessage === null) return enviar('Marque a Mensagem da Pessoa que Deseja Banir!')
if(info.message.extendedTextMessage.contextInfo.participant !== null && info.message.extendedTextMessage.contextInfo.participant != undefined && info.message.extendedTextMessage.contextInfo.participant !== "") {
mentioned = info.message.extendedTextMessage.contextInfo.mentionedJid[0] ? info.message.extendedTextMessage.contextInfo.mentionedJid[0] : info.message.extendedTextMessage.contextInfo.participant
let responseb = await sophy.groupParticipantsUpdate(from, [mentioned], 'remove')
if (responseb[0].status === "200") return enviar(`*Usuário Removido do Grupo com Sucesso 🤡*`)
else if (responseb[0].status === "406") return enviar('Como vc quer que eu Remova o Adm Supremacy????')
else if (responseb[0].status === "404") return enviar('*Este Usuário já foi Removido ou Saiu do Grupo')
else return reply('tenta dnv')
} else if (info.message.extendedTextMessage.contextInfo.mentionedJid != null && info.message.extendedTextMessage.contextInfo.mentionedJid != undefined) {
mentioned = info.message.extendedTextMessage.contextInfo.mentionedJid
if(mentioned.length > 1) {
if(mentioned.length > groupMembers.length || mentioned.length === groupMembers.length || mentioned.length > groupMembers.length - 3) return enviar(`Vai Arquivar o Grupo Msm??`)
sexocomrato = 0
for (let banned of mentioned) {
await sleep(100)
let responseb2 = await sophy.groupParticipantsUpdate(from, [banned], 'remove')
if (responseb2[0].status === "200") sexocomrato = sexocomrato + 1
}
return reply(``)
} else {
let responseb3 = await sophy.groupParticipantsUpdate(from, [mentioned[0]], 'remove')
if (responseb3[0].status === "200") return enviar(`Usuário Removido do Grupo com Sucesso!`)
else if (responseb3[0].status === "406") return enviar('Como vc quer que eu Remova o Adm Supremacy????')
else if (responseb3[0].status === "404") return enviar('Esse Usuário já foi Removido ou Saiu do Grupo!')
else return enviar('Tenta denovo ai Lek')
}
}
}
break


case 'add':
if(!isRegistro) return reply(`Use: ${prefix}Login Para se Registrar no Bot`)
if (!isGroup) return reply('Comando só Pode ser Usado em Grupo!')
if (!isBotAdmins) return enviar('Preciso ser ADM para Realizar essa Ação!')
if (!isGroupAdmins) return enviar('Você não é Um Administrador!')
if(!q.trim()) return enviar(`Cadê o Número pra Adicionar?`)
try {
useradd = `${args.join(" ").replace(/\D/g,'')}` ? `${args.join(" ").replace(/\D/g,'')}` : info.message.extendedTextMessage.contextInfo.participant
let id = `${useradd.replace(/\D/g,'')}`
if(!id) return enviar(`Número Inválido Amigo(a)`)
let [result] = await sophy.onWhatsApp(id)
if(!result) return enviar(`Esse Número não Está Registrado no WhatsApp!`)
let response = await sophy.groupParticipantsUpdate(from, [result.jid], "add")
if(response[0].status == "409") {
sophy.sendMessage(from, {text: `Mas Ele já Está no Grupo!`, mentions: [result.jid, sender]})
} else if(response[0].status == "403") {
sophy.sendMessage(from, {text: `Não Consegui Adicionar o @${result.jid.split("@")[0]}, Porque ele Privou o Número!`, mentions: [result.jid, sender]})
} else if(response[0].status == "408") {
sophy.sendMessage(from, {text: `Não Consegui Adicionar o @${result.jid.split("@")[0]}, Porque ele Saiu Recentemente do Grupo!`, mentions: [result.jid, sender]})
} else if(response[0].status == "401") {
sophy.sendMessage(from, {text: `Não Consegui Adicionar o @${result.jid.split("@")[0]} Porque ele me Bloqueou!`, mentions: [result.jid, sender]})
} else if(response[0].status == "200") {
sophy.sendMessage(from, {text: `Prontinho, Fiz o que Você me Pediu!!`, mentions: [result.jid, sender]})
} else {
enviar("Vish, Algo deu Errado Lek")
}
} catch {
}
break


case 'promover':
 if(!isRegistro) return reply(`Use: ${prefix}Login Para se Registrar no Bot`)
if (!isGroup) return reply('Comando só Pode ser Usado em Grupo!')
if (!isBotAdmins) return enviar('Preciso ser ADM para Realizar essa Ação!')
if (!isGroupAdmins) return enviar('Você não é Um Administrador!')
if (info.message.extendedTextMessage === undefined || info.message.extendedTextMessage === null) return enviar('Vai colocar o Vento como Adm???')
mentioned = info.message.extendedTextMessage.contextInfo.mentionedJid[0] ? info.message.extendedTextMessage.contextInfo.mentionedJid[0] : info.message.extendedTextMessage.contextInfo.participant
let responsedm = await sophy.groupParticipantsUpdate(from, [mentioned], 'promote')
if (responsedm[0].status === "200") return enviar('Eita Eita, Parece que Temos um Novo ADM no Grupo!')
else if (responsedm[0].status === "404") return enviar('Mai esse Maluco Nem está no Grupo 🤔')
else return reply('Tenta dnv '-'')
break


case 'rebaixar':
if(!isRegistro) return reply(`Use: ${prefix}Login Para se Registrar no Bot`)
if (!isGroup) return reply('Comando só Pode ser Usado em Grupo!')
if (!isBotAdmins) return enviar('Preciso ser ADM para Realizar essa Ação!')
if (!isGroupAdmins) return enviar('Você não é Um Administrador!')
if (info.message.extendedTextMessage === undefined || info.message.extendedTextMessage === null) return enviar('Marque ou Responda a Mensagem de Quem você quer Tirar de Admin!')
mentioned = info.message.extendedTextMessage.contextInfo.mentionedJid[0] ? info.message.extendedTextMessage.contextInfo.mentionedJid[0] : info.message.extendedTextMessage.contextInfo.participant
let responsepm = await sophy.groupParticipantsUpdate(from, [mentioned], 'demote')
if (responsepm[0].status === "406") return enviar('Como vc Quer que eu Remova o Adm Supremacy????')
else if (responsepm[0].status === "200") return enviar('Você Perdeu o Cargo de Adm por motivos Justo, Lamento você Não e mais Adm desse Grupo!')
else if (responsepm[0].status === "404") return enviar('Mais esse Cara nem ta no Grupo garay 🧐')
else return enviar('Tenta denovo ai Lek')
break


case "grupo":
 if(!isRegistro) return reply(`Use: ${prefix}Login Para se Registrar no Bot`)
if (!isGroup) return reply('Comando só Pode ser Usado em Grupo!')
if (!isBotAdmins) return enviar('Preciso ser ADM para Realizar essa Ação!')
if (!isGroupAdmins) return enviar('Você não é Um Administrador!')
try {
if (q == "a") {
await sophy.groupSettingUpdate(from, "not_announcement")
reply("𓆩Grupo Aberto com Sucesso𓆪")
}
if (q == "f") {
await sophy.groupSettingUpdate(from, "announcement")
reply("𓆩Grupo Fechado com Sucesso𓆪")
}
} catch(e) {
console.log(e)
enviar(resposta.erro)
}
break


//_______________COMANDOS ADM_______________//

case 'metadinha':
if(!isRegistro) return reply(`Use: ${prefix}Login Para se Registrar no Bot`)
await sophy.sendMessage(from, { react: { text: `💫`, key: info.key }})
anuu = await fetchJson('https://raw.githubusercontent.com/iamriz7/kopel_/main/kopel.json')
random = anuu[Math.floor(Math.random() * anuu.length)]
let buttonssMessssage = {
image: { url: random.male },
caption: `𓆩ᴍᴀsᴄᴜʟɪɴᴏ𓆪`,
footer: `${botName}`,
headerType: 4
}
await sophy.sendMessage(from, buttonssMessssage, { quoted: imgm }).catch(err => {
return ('Error!')
})
let buttonssMesssage = {
image: { url: random.female },
caption: `𓆩ғᴇᴍɪɴɪɴᴏ𓆪`,
footer: `${botName}`,
headerType: 4
}
await sophy.sendMessage(from, buttonssMesssage, { quoted: imgm }).catch(err => {
return ('Error!')
})
break


case 'wallpaper':
if(!isRegistro) return reply(`Use: ${prefix}Login Para se Registrar no Bot`)
reply("𓆩Tô Enviando no Seu Privado𓆪")
google = await fetchJson(`https://clover-t-bot.onrender.com/wallpaper/ppcouple?key=Lady-Bot&username=Lady-Bot`)
sophy.sendMessage(sender, { image: { url: google.url } }, { quoted: imgm })
break


case 'memes': {
if(!isRegistro) return reply(`Use: ${prefix}Login Para se Registrar no Bot`)
await sophy.sendMessage(from, { react: { text: `👹`, key: info.key }})
fetch('https://clover-t-bot.onrender.com/memes?username=SUPREMO&key=SER_SUPREMO').then(response => response.json()).then(data => {
sophy.sendMessage(from, { video: { url: `${data.url}` } }, { quoted: vid })
})
} 
break


case 'recados':
if(!isRegistro) return reply(`Use: ${prefix}Login Para se Registrar no Bot`)
await sophy.sendMessage(from, { react: { text: "📝", key: info.key }})
await delay(800)
rate = body.slice(6)
var foda =['Felicidade é só questão de ser.','Acredite: sempre tem algo bom guardado para você','Concentre-se no que está buscando, não no que está deixando para trás.','A vida é muito curta pra não viver sorrindo por aí!','Onde há vontade, há chance de dar certo!','Dance no seu ritmo! 💃','Só você sabe o que te deixará feliz.','Não se estresse com o que está fora do seu controle.','Aprenda a apreciar as voltas que o mundo dá.','Comece a se amar. O resto virá depois.','Maior que a tristeza de não haver vencido é a vergonha de não ter lutado!','Reciprocidade, para as coisa boas. Imunidade, para as coisas ruins.','Coragem, a vida gosta de pessoas destemidas.', 'Compartilhe seus sentimentos. Nem todas as pessoas sabem adivinhar','Continue caminhando, não tem problema se for devagar.','Melhor amar do que ser amargo!','Não corrigir nossas falhas é o mesmo que cometer novos erros','Quando o caminho se torna duro, só os duros continuam caminhando','Florescer exige passar por todas as estações!','Quando as coisas simples parecem especiais, você percebe como a vida pode ser boa.','Os aprendizados deixam a vida especial.','Feliz daquele que encontra o verdadeiro amor sem as cicatrizes da decepção']
var vitin = foda[Math.floor(Math.random() * foda.length)]
reply(`𝐒𝐄𝐔 𝐑𝐄𝐂𝐀𝐃𝐎: ${vitin}`)
break


case "imgpralink":
if(!isRegistro) return reply(`Use: ${prefix}Login Para se Registrar no Bot`)
try {
if (isQuotedImage) {
boij = isQuotedImage || isQuotedVideo ? JSON.parse(JSON.stringify(info).replace("quotedM", "m")).message.extendedTextMessage.contextInfo.message.imageMessage : info
const fetch = require('node-fetch');
const FormData = require('form-data');
const fs = require('fs');
async function uploadImageToTelegraph(imageBuffer) {
const form = new FormData();
form.append('file', imageBuffer, { filename: 'image.jpg' });
const response = await fetch('https://telegra.ph/upload', {
method: 'POST',
body: form,
});
const data = await response.json();
if (data && data[0] && data[0].src) {
return 'https://telegra.ph' + data[0].src;
} else {
throw new Error('Failed to retrieve the image URL from the response.');
}
}
const owgi = await getFileBuffer(boij, "image");
const imageUrl = await uploadImageToTelegraph(owgi);
reply(imageUrl);
} else {
enviar('Marque uma Imagem para Torná-la em Link!')
}
} catch (e) {
console.log(e)
enviar('error...')
}
break


//_______________DOWNLOADS_______________//

case 'música':
if(!isRegistro) return reply(`Use: ${prefix}Login Para se Registrar no Bot`)
if (!q) return enviar(`Exemplo: ${prefix}Música Mc Paiva`)
await sophy.sendMessage(from, { react: { text: `🎵`, key: info.key }})
fetch(`https://clover-t-bot.onrender.com/yt/playmp4?query=${q}&key=Lady-Bot&username=Lady-Bot`).then(response => response.json()).then(ytbr => {
sophy.sendMessage(from, { image: { url: `${ytbr.thumb}` }, caption: `       🥂𝐁𝐄𝐌✰𝐕𝐈𝐍𝐃𝐎🥂   ♬
     ⏤͟͟͞͞${pushname}   ☁︎

⟬🎬⟭ ɴᴏᴍᴇ:  ҂ ${ytbr.title}\n
⟬💿⟭ ᴄᴀɴᴀʟ:  ҂ ${ytbr.channel}\n
⟬🧸⟭ ᴠɪᴇᴡs:  ҂ ${ytbr.views}

1:28 ❍──────2:36 ↻ ⊲ Ⅱ ⊳ ↺
ᴠᴏʟᴜᴍᴇ : ▮▮▮▮▮▮▮▮▯▯▯
` }, { quoted: info })
sophy.sendMessage(from, { audio: { url: ytbr.url }, mimetype: 'audio/mpeg' }, { quoted: mus })
})
break


case 'vídeo':
if(!isRegistro) return reply(`Use: ${prefix}Login Para se Registrar no Bot`)
if (!q) return enviar(`Exemplo: ${prefix}Vídeo Mc Paiva`)
await sophy.sendMessage(from, { react: { text: `🎬`, key: info.key }})
fetch(`https://clover-t-bot.onrender.com/yt/playmp4?query=${q}&key=Lady-Bot&username=Lady-Bot`).then(response => response.json()).then(ytbr => {
sophy.sendMessage(from, { image: { url: `${ytbr.thumb}` }, caption: `       🥂𝐁𝐄𝐌✰𝐕𝐈𝐍𝐃𝐎🥂   ♬
     ⏤͟͟͞͞${pushname}   ☁︎

⟬🎬⟭ ɴᴏᴍᴇ:  ҂ ${ytbr.title}\n
⟬💿⟭ ᴄᴀɴᴀʟ:  ҂ ${ytbr.channel}\n
⟬🧸⟭ ᴠɪᴇᴡs:  ҂ ${ytbr.views}

1:28 ❍──────2:36 ↻ ⊲ Ⅱ ⊳ ↺
ᴠᴏʟᴜᴍᴇ : ▮▮▮▮▮▮▮▮▯▯▯
` }, { quoted: info })
sophy.sendMessage(from, { video: { url: ytbr.url }, mimetype: 'video/mp4' }, { quoted: vid })
})
break


case 'tiktokmp4':
if(!isRegistro) return reply(`Use: ${prefix}Login Para se Registrar no Bot`)
try {
if(!q) return enviar("Ei, Cadê o Link Meu fih?")
if (!q.includes('tiktok')) return reply(`Link Invalido..!!`)
await reply(`𓆩Um momento, Já está Indo𓆪`)
thumbnail: fs.readFileSync(`./settings/logo.jpg`),
require('./arquivos/lib/tiktok').Tiktok(q).then( date => {
sophy.sendMessage(from, { video: { url: date.nowm }}, { quoted: vid })
})
} catch {
enviar("Deu erro, esse link Não e do Tik Tok...")
}
break


case 'tiktokmp3':
if(!isRegistro) return reply(`Use: ${prefix}Login Para se Registrar no Bot`)
try {
if(!q) return enviar("Ei, Cadê o Link Meu fih?")
if (!q.includes('tiktok')) return reply(`Link Invalido..!!`)
await reply(`𓆩Um momento, Já está Indo𓆪`)
require('./arquivos/lib/tiktok').Tiktok(q).then( date => {
sophy.sendMessage(from, { audio: { url: date.audio }, mimetype: 'audio/mp4' }, { quoted: mus })
})
} catch {
enviar("Deu erro, esse Link não e do Tik Tok")
}
break


case 'soundcloud':
if(!isRegistro) return reply(`Use: ${prefix}Login Para se Registrar no Bot`)
if(!q) return enviar(`Adicione um Link do SoundCloud
Exemplo: ${prefix}soundcloud "Seu Link"`)
tkk = await fetchJson(`https://yumeko-api.onrender.com/api/dl/sound?link=${q}&apikey=freekey`)
await reply('𓆩Paciência, Já estou Enviando𓆪')
sophy.sendMessage(from, {image: await getBuffer(tkk.resultado.capa), 
caption: `Nome: ${tkk.resultado.titulo}
Total de Downloads: ${tkk.resultado.total_downloads}`}, {quoted: info})
sophy.sendMessage(from, {audio: await getBuffer(tkk.resultado.link_dl), mimetype: 'audio/mpeg'}, {quoted: mus})
break


//_______________BRINCADEIRAS_______________//

case "ppt":
if(!isRegistro) return reply(`Use: ${prefix}Login Para se Registrar no Bot`)
if (args.length < 1) return enviar(`Você deve Digitar: ${prefix}ppt Pedra, ${prefix}ppt Papel ou ${prefix}ppt Tesoura!`)
ppt = ["pedra", "papel", "tesoura"]
ppy = ppt[Math.floor(Math.random() * ppt.length)]
ppg = Math.floor(Math.random() * 1) + 10
pptb = ppy
if ((pptb == "pedra" && args == "papel") ||
(pptb == "papel" && args == "tesoura") ||
(pptb == "tesoura" && args == "pedra")) {
var vit = "vitoria"
} else if ((pptb == "pedra" && args == "tesoura") ||
(pptb == "papel" && args == "pedra") ||
(pptb == "tesoura" && args == "papel")) {
var vit = "derrota"
} else if ((pptb == "pedra" && args == "pedra") ||
(pptb == "papel" && args == "papel") ||
(pptb == "tesoura" && args == "tesoura")) {
var vit = "empate"
} else if (vit = "undefined") {
return enviar(`Você deve Digitar: ${prefix}ppt Pedra, ${prefix}ppt Papel ou ${prefix}ppt Tesoura!`)
}
if (vit == "vitoria") {
var tes = "Você ganhou -_-"
}
if (vit == "derrota") {
var tes = "Eu ganhei pobre kkkkkk"
}
if (vit == "empate") {
var tes = "Deu empate 😐"
}
reply(`${botName} jogou: ${pptb}\nO jogador jogou: ${args}\n\n${tes}`)
if (tes == "Vitória do jogador") {
enviar(pph)
}
break


case 'chance':
if(!isRegistro) return reply(`Use: ${prefix}Login Para se Registrar no Bot`)
rate = body.slice(7)
zxzz = 
random = `${Math.floor(Math.random() * 200)}`
reply('⊱A Chance é De: ❰ '+random+'% ❱⊰') 
break


case 'adivinhar':
if(!isRegistro) return reply(`Use: ${prefix}Login Para se Registrar no Bot`)
if (args.length < 1) return enviar(`Exemplo: ${prefix} Adivinhar 35`)
const num = Math.floor(Math.random() * 100) + 1
const guess = parseInt(args[0])
if (isNaN(guess)) return reply('Digite um número válido.')
if (guess < 1 || guess > 100) return enviar('O Número Deve estár Entre (1 a 100)')
if (guess === num) {
const premio = Math.floor(Math.random() * 50) + 1
reply(`Parabéns, Você Acertou! O número Era: (${num})\nVocê ganhou (${premio}) Como Prêmio!`)
} else {
reply(`Você Errou, O Número Era: (${num})`)
}
break


case 'escolher': {
if(!isRegistro) return reply(`Use: ${prefix}Login Para se Registrar no Bot`)
const opcoes = args.join(' ').split('/');
if (opcoes.length < 2) {
enviar('Por Favor, Forneça Pelo Menos Duas Opções Separadas Por: "/"');
return;
}
const randomIndex = Math.floor(Math.random() * opcoes.length);
const escolhaAleatoria = opcoes[randomIndex];
reply(`🔮 Minha Escolha é: ${escolhaAleatoria}`);
}
break


//_______________FIGURINHAS_______________//

case 's': 
case 'f': 
case 'stk':
case 'fig':
case 'sticker':
{
(async function () {
var legenda = q ? q?.split("/")[0] : `❒ COMANDO: 
❒ CRIADOR: 
❒ NÚMERO: 
❒ CHAT: 
❒ NOME: 
❒ DONO:
❒ BOT: `
var autor = q ? q?.split("/")[1] : q?.split("/")[0] ? '' : `❒ .sticker
❒ ${pushname}
❒ ${sender.split("@")[0]}
❒ ${!isGroup ? `${pushname}` :  `${groupName}`}
❒ ${botName}
❒ ${donoName}
❒ ${numeroBot}`
if (isMedia && !info.message.videoMessage || isQuotedImage) {
var encmedia = isQuotedImage ? info.message.extendedTextMessage.contextInfo.quotedMessage.imageMessage : info.message.imageMessage
rane = getRandom('.'+await getExtension(encmedia.mimetype))
buffimg = await getFileBuffer(encmedia, 'image')
fs.writeFileSync(rane, buffimg)
rano = getRandom('.webp')
exec(`ffmpeg -i ${rane} -vcodec libwebp -filter:v fps=fps=15 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 800:800 ${rano}`, (err) => {
fs.unlinkSync(rane)
var json = {
"sticker-pack-name": botName,
"sticker-pack-publisher": pushname
}
var exifAttr = Buffer.from([0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00])
var jsonBuff = Buffer.from(JSON.stringify(json), "utf-8")
var exif = Buffer.concat([exifAttr, jsonBuff])
exif.writeUIntLE(jsonBuff.length, 14, 4)
let nomemeta = Math.floor(Math.random() * (99999 - 11111 + 1) + 11111)+".temp.exif"
fs.writeFileSync(`./${nomemeta}`, exif) 
exec(`webpmux -set exif ${nomemeta} ${rano} -o ${rano}`, () => {
sophy.sendMessage(from, {sticker: fs.readFileSync(rano)}, {quoted: contato})
fs.unlinkSync(nomemeta)
fs.unlinkSync(rano)
})
})
} else if (isMedia && info.message.videoMessage.seconds < 11 || isQuotedVideo && info.message.extendedTextMessage.contextInfo.quotedMessage.videoMessage.seconds < 35) {
var encmedia = isQuotedVideo ? info.message.extendedTextMessage.contextInfo.quotedMessage.videoMessage : info.message.videoMessage
rane = getRandom('.'+await getExtension(encmedia.mimetype))
buffimg = await getFileBuffer(encmedia, 'video')
fs.writeFileSync(rane, buffimg)
rano = getRandom('.webp')
await ffmpeg(`./${rane}`)
.inputFormat(rane.split('.')[1])
exec(`ffmpeg -i ${rane} -vcodec libwebp -filter:v fps=fps=15 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 200:200 ${rano}`, (err) => {
fs.unlinkSync(rane)
let json = {
"sticker-pack-name": botName,
"sticker-pack-publisher": pushname
}
let exifAttr = Buffer.from([0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00])
let jsonBuff = Buffer.from(JSON.stringify(json), "utf-8")
let exif = Buffer.concat([exifAttr, jsonBuff])
exif.writeUIntLE(jsonBuff.length, 14, 4)
let nomemeta = "temp.exif"
fs.writeFileSync(`./${nomemeta}`, exif) 
exec(`webpmux -set exif ${nomemeta} ${rano} -o ${rano}`, () => {
sophy.sendMessage(from, {sticker: fs.readFileSync(rano)}, {quoted: contato})
fs.unlinkSync(nomemeta)
fs.unlinkSync(rano)
})
})
} else {
enviar('Você Precisa Marcar uma Image ou Vídeo com no Máximo 10s') 
}
})().catch(e => {
console.log(e)
enviar("Ish, Deu erro Lek")
try {
if (fs.existsSync("temp.exif")) fs.unlinkSync("temp.exif");
if (fs.existsSync(rano)) fs.unlinkSync(rano);
if (fs.existsSync(media)) fs.unlinkSync(media);
} catch {}
})
}
break


case 'attp1': 
case 'attp2': 
case 'attp3': 
case 'attp4': 
case 'attp5': 
case 'attp6': 
case 'attp7': 
if(!isRegistro) return reply(`Use: ${prefix}Login Para se Registrar no Bot`)
if(!q) return enviar("Ei, Cadê o Texto? ")
reply("𓆩Enviando, Acalma o Coração𓆪")
att = await getBuffer(`https://tohsaka.onrender.com/api/maker/${command}?texto=${q}&apikey=e6cxOVCbPQ`)
sophy.sendMessage(from, {sticker: att}, {quoted: info})
break


//_______________ALTERADORES_______________//

case 'esquilo':
if(!isRegistro) return reply(`Use: ${prefix}Login Para se Registrar no Bot`)
if (!isQuotedAudio) return enviar('Marque um Áudio para Modificá-lo!')
reply('𓆩Paciência, Já estou Enviando𓆪')
muk = isQuotedAudio ? info.message.extendedTextMessage.contextInfo.quotedMessage.audioMessage : info.message.audioMessage
rane = getRandom('.'+await getExtension(muk.mimetype))
buffimg = await getFileBuffer(muk, 'audio')
fs.writeFileSync(rane, buffimg)
gem = rane
ran = getRandom('.mp3')
exec(`ffmpeg -i ${gem} -filter:a "atempo=0.7,asetrate=65100" ${ran}`, (err, stderr, stdout) => {
fs.unlinkSync(gem)
if (err) return reply('Error!')
hah = fs.readFileSync(ran)
sophy.sendMessage(from, {audio: hah, mimetype: 'audio/mp4', ptt:true}, {quoted: mus})
fs.unlinkSync(ran)
})
break


case 'slowed':
if(!isRegistro) return reply(`Use: ${prefix}Login Para se Registrar no Bot`)
if (!isQuotedAudio) return enviar('Marque um Áudio para Modificá-lo!')
reply('𓆩Paciência, Já estou Enviando𓆪')
muk = isQuotedAudio ? info.message.extendedTextMessage.contextInfo.quotedMessage.audioMessage : info.message.audioMessage
rane = getRandom('.'+await getExtension(muk.mimetype))
buffimg = await getFileBuffer(muk, 'audio')
fs.writeFileSync(rane, buffimg)
gem = rane
ran = getRandom('.mp3')
exec(`ffmpeg -i ${gem} -filter:a "atempo=0.9,asetrate=44100" ${ran}`, (err, stderr, stdout) => {
fs.unlinkSync(gem)
if (err) return reply('Error!')
hah = fs.readFileSync(ran)
sophy.sendMessage(from, {audio: hah, mimetype: 'audio/mp4', ptt:true}, {quoted: mus})
fs.unlinkSync(ran)
})
break


case 'estourar':
if(!isRegistro) return reply(`Use: ${prefix}Login Para se Registrar no Bot`)
if (!isQuotedAudio) return enviar('Marque um Áudio para Modificá-lo!')
reply('𓆩Paciência, Já estou Enviando𓆪')
muk = isQuotedAudio ? info.message.extendedTextMessage.contextInfo.quotedMessage.audioMessage : info.message.audioMessage
rane = getRandom('.'+await getExtension(muk.mimetype))
buffimg = await getFileBuffer(muk, 'audio')
fs.writeFileSync(rane, buffimg)
gem = rane
ran = getRandom('.mp3')
exec(`ffmpeg -i ${gem} -af equalizer=f=90:width_type=o:width=2:g=30 ${ran}`, (err, stderr, stdout) => {
fs.unlinkSync(gem)
if (err) return reply('Error!')
hah = fs.readFileSync(ran)
sophy.sendMessage(from, {audio: hah, mimetype: 'audio/mp4', ptt:true}, {quoted: mus})
fs.unlinkSync(ran)
})
break


case 'grave': 
if(!isRegistro) return reply(`Use: ${prefix}Login Para se Registrar no Bot`)
if (!isQuotedAudio) return enviar('Marque um Áudio para Modificá-lo!')
reply('𓆩Paciência, Já estou Enviando𓆪')
muk = isQuotedAudio ? info.message.extendedTextMessage.contextInfo.quotedMessage.audioMessage : info.message.audioMessage
rane = getRandom('.'+await getExtension(muk.mimetype))
buffimg = await getFileBuffer(muk, 'audio')
fs.writeFileSync(rane, buffimg)
gem = rane
ran = getRandom('.mp3')
exec(`ffmpeg -i ${gem} -af equalizer=f=20:width_type=o:width=2:g=15 ${ran}`, (err, stderr, stdout) => {
fs.unlinkSync(gem)
if (err) return reply('Error!')
hah = fs.readFileSync(ran)
sophy.sendMessage(from, {audio: hah, mimetype: 'audio/mp4', ptt:true}, {quoted: mus})
fs.unlinkSync(ran)
})
break


//_______________IMG-ANIME_______________//

case 'mikasa':
if(!isRegistro) return reply(`Use: ${prefix}Login Para se Registrar no Bot`)
reply("𓆩Tô Enviando no Seu Privado𓆪")
google = await fetchJson(`https://clover-t-bot.onrender.com/nime/mikasa?key=958397&username=Nativa`)
sophy.sendMessage(sender, { image: { url: google.url } }, { quoted: imgm })
break


case 'nezuko':
if(!isRegistro) return reply(`Use: ${prefix}Login Para se Registrar no Bot`)
reply("𓆩Tô Enviando no Seu Privado𓆪")
google = await fetchJson(`https://clover-t-bot.onrender.com/nime/nezuko?key=958397&username=Nativa`)
sophy.sendMessage(sender, { image: { url: google.url } }, { quoted: imgm })
break


case 'yumeko':
if(!isRegistro) return reply(`Use: ${prefix}Login Para se Registrar no Bot`)
reply("𓆩Tô Enviando no Seu Privado𓆪")
google = await fetchJson(`https://clover-t-bot.onrender.com/nime/yumeko?key=958397&username=Nativa`)
sophy.sendMessage(sender, { image: { url: google.url } }, { quoted: imgm })
break


case 'sasuke':
if(!isRegistro) return reply(`Use: ${prefix}Login Para se Registrar no Bot`)
reply("𓆩Tô Enviando no Seu Privado𓆪")
google = await fetchJson(`https://clover-t-bot.onrender.com/nime/sasuke?key=958397&username=Nativa`)
sophy.sendMessage(sender, { image: { url: google.url } }, { quoted: imgm })
break


case 'madara':
if(!isRegistro) return reply(`Use: ${prefix}Login Para se Registrar no Bot`)
reply("𓆩Tô Enviando no Seu Privado𓆪")
google = await fetchJson(`https://clover-t-bot.onrender.com/nime/madara?key=958397&username=Nativa`)
sophy.sendMessage(sender, { image: { url: google.url } }, { quoted: imgm })
break


//_______________IMG-LOGOS_______________//

case 'angelwing':  
case 'hackneon': 
case 'ffavatar':
case 'angelglx': 
case 'logogame':
if(!isRegistro) return reply(`Use: ${prefix}Login Para se Registrar no Bot`)
try {
if(!q.trim()) return enviar(`Digite algo, Exemplo: ${prefix+command} Sophy-MD`);  
reply("𓆩Gerando, Aguarde um Instante𓆪");
ABC = await fetchJson(`https://api.bronxyshost.com.br/api-bronxys/logos_EPH?texto=${q}&category=${command}&apikey=${API_KEY_NATIVA}`);
sophy.sendMessage(from, {image: {url: ABC.resultado}}, {quoted: imgm}).catch(() => {
return enviar("Erro..")
})
} catch (e) {
return enviar("Erro...");
}
break;



default:
//FIM DOS COMANDOS BY NATIVA



//MENSAGEM DE CMD INVÁLIDO

if (isCmd) sophy.sendMessage(from, { react: { text: `🚫`, key: info.key }})

//===========CMD DE ÁUDIO SEM PREFIXO========\\

// Responder, Caso O Número Seja Marcado no Grupo 
 if (body.includes(`@558391780744`)) {
 if (info.key.fromMe) return 
sophy.sendMessage(m.chat, {sticker: fs.readFileSync(`./figurinhas/halerquin.webp`)}, {quoted: contato});
 }
//━━━━━━━❰･NOME SEM PREFIXO･❱━━━━━━━\\

if(budy.match("🏳️‍🌈")) {
bla = fs.readFileSync("./figurinhas/🏳️‍🌈.webp")
sophy.sendMessage(from, {sticker: bla}, {quoted: contato})
}

if(budy.match("😐")) {
bla = fs.readFileSync("./figurinhas/smoke.webp")
sophy.sendMessage(from, {sticker: bla}, {quoted: contato})
}

if(budy.match("😏")) {
bla = fs.readFileSync("./figurinhas/halerquin.webp")
sophy.sendMessage(from, {sticker: bla}, {quoted: contato})
}

if(budy.match("😋")) {
bla = fs.readFileSync("./figurinhas/coxinha.webp")
sophy.sendMessage(from, {sticker: bla}, {quoted: contato})
}

if(budy.match("sexo") || (budy.match("Sexo"))) {
bla = fs.readFileSync("./figurinhas/168.webp")
sophy.sendMessage(from, {sticker: bla}, {quoted: contato})
}

if(budy.match("Tedio") || (budy.match("tedio") || (budy.match("Tédio")))) {
bla = fs.readFileSync("./figurinhas/164.webp")
sophy.sendMessage(from, {sticker: bla}, {quoted: contato})
}

if(budy.match("blz") || (budy.match("Blz") || (budy.match("BLZ")))) {
bla = fs.readFileSync("./figurinhas/28.webp")
sophy.sendMessage(from, {sticker: bla}, {quoted: contato})
}

if(budy.match("😢") || (budy.match("😪") || (budy.match("😭")))) {
bla = fs.readFileSync("./figurinhas/131.webp")
sophy.sendMessage(from, {sticker: bla}, {quoted: contato})
}

if(budy.match("bot chato") || (budy.match("Bot chato") || (budy.match("Bot Chato")))) {
bla = fs.readFileSync("./figurinhas/26.webp")
sophy.sendMessage(from, {sticker: bla}, {quoted: contato})
}

if(budy.match("🥺") || (budy.match("😶") || (budy.match("💔")))) {
bla = fs.readFileSync("./figurinhas/49.webp")
sophy.sendMessage(from, {sticker: bla}, {quoted: contato})
}

if(budy.match("😠") || (budy.match("😡") || (budy.match("🤬")))) {
bla = fs.readFileSync("./figurinhas/28.webp")
sophy.sendMessage(from, {sticker: bla}, {quoted: contato})
}

}} catch (erro) {
console.log(erro)
}})



sophy.ev.on('connection.update', (update) => {
const { connection, lastDisconnect } = update
if(lastDisconnect === undefined) {

}

if(connection === 'close') {
var shouldReconnect = (lastDisconnect.error.Boom)?.output?.statusCode !== DisconnectReason.loggedOut  
startActivity()
}})}
startActivity()

fs.watchFile('./menus/alugar.js', (curr, prev) => {
if (curr.mtime.getTime() !== prev.mtime.getTime()) {
console.log('O Menu foi editada, irei reiniciar...');
process.exit()
}
})

fs.watchFile('./menus/menudono.js', (curr, prev) => {
if (curr.mtime.getTime() !== prev.mtime.getTime()) {
console.log('O Menu foi editada, irei reiniciar...');
proce/s.exit()
}
})

fs.watchFile('./menus/menu.js', (curr, prev) => {
if (curr.mtime.getTime() !== prev.mtime.getTime()) {
console.log('O Menu foi editada, irei reiniciar...');
process.exit()
}
})

fs.watchFile('./index.js', (curr, prev) => {
if (curr.mtime.getTime() !== prev.mtime.getTime()) {
console.log('A index foi editada, irei reiniciar...');
process.exit()
}
})

fs.watchFile('./config.js', (curr, prev) => {
if (curr.mtime.getTime() !== prev.mtime.getTime()) {
console.log('A config foi editada, irei reiniciar...');
process.exit()
}
})