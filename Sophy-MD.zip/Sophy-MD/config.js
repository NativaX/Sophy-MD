const { fs } =  require( "fs")

global.donoName = "иαтινα 🕊️" //nome do dono
global.botName = "Sophy-MD" //nome do bot
global.donoNumher = "558391780744" //nuemero do dono
global.numeroBot = "558393919004" //nuemro do bot
global.prefix = "/" //prefixo do bot
// nao apague "

tapão = "https://telegra.ph/file/841664f31eb7539c35a2d.mp4"
//Gif da Brincadeira de Tapa
beijão = "https://telegra.ph/file/dc5962ec8202ffc3d49c1.mp4"
//Gif da Brincadeira de beijo
gayzão = "https://telegra.ph/file/8c6a748b7642c2a9d4b5e.jpg"
//Imagem da Brincadeira de Gay
feião = "https://telegra.ph/file/8c9fe13c7d77bb2d62c03.jpg"
//Imagem da Brincadeira de Feio
mateii = "https://telegra.ph/file/1135a19fceefa7074caf8.mp4"
//Gif da Brincadeira de Matar
cornão = "https://telegra.ph/file/3182942e577dbbc27b17e.jpg"
//Imagem da Brincadeira de Corno
vesgão = "https://telegra.ph/file/93f84abd5eac215d2868a.jpg"
//Imagen da Brincadeira de Vesgo
bebão = "https://telegra.ph/file/b69ac603e275e610d2c34.jpg"
//Imagem da Brincadeira de Bêbado 
gadão = "https://telegra.ph/file/6ac2858647969cca031fd.jpg"
//Imagem da Brincadeira de Gado
gostosão = "https://telegra.ph/file/ac9a9ba3b6af7fe5c3d2b.jpg"
//Imagem da Brincadeira de Gostoso
gostosona = "https://telegra.ph/file/20a8a295064d2a4481997.jpg"
//Imagem da Brincadeira de Gostosa
nazista = "https://telegra.ph/file/fb2762032047db19d206b.jpg"
//Imagem da Brincadeira de Nazista
chutão = "https://telegra.ph/file/d4b2525d2e1aeb33fa626.mp4"
//Gif da Brincadeira de Chute
dança = "https://telegra.ph/file/e90ea86031158b7298ee4.mp4"
//Gif da Brincadeira de Dança 
casar = "https://telegra.ph/file/e9b02f179ff4e70baaeab.mp4"
//Gif da Brincadeira de Casar
socão = "https://telegra.ph/file/f737009edab409fe7be43.mp4"
//Gif da Brincadeira de soco

aquamoji1 = "❤️"
aquamoji2 = "💔"
aquamoji3 = "‼️"
aquamoji4 = "🔞"
aquamoji5 = "👹"
aquamoji6 = "🩸️"
aquamoji7 = "❗"