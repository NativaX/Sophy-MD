exports.menu = (comando, prefix, time, date, pushname) => {
return `
╭───∘⟬𝐈𝐍𝐅𝐎/𝐔𝐒𝐄𝐑⟭∘───⪨
│🤖 𝗕𝗼𝘁: ${botName}
│👤 𝗨𝘀𝘂𝗮́𝗿𝗶𝗼: ${pushname}
│🥷🏽 𝗖𝗿𝗶𝗮𝗱𝗼𝗿: ${donoName}
│⚙️ 𝗣𝗿𝗲𝗳𝗶𝘅𝗼: [ ${prefix} ]
│🕒 𝗛𝗼𝗿𝗮: ${time}
│📅 𝗗𝗮𝘁𝗮: ${date}
╰─────────────────⪨

╭───∘⟬𝐌𝐄𝐍𝐔-𝐀𝐃𝐌⟭∘───⪨
│ঔৣ͜͡⪩${prefix}Grupo [a/f]
│ঔৣ͜͡⪩${prefix}Add [@] 
│ঔৣ͜͡⪩${prefix}Ban [@] 
│ঔৣ͜͡⪩${prefix}Promover [@] 
│ঔৣ͜͡⪩${prefix}Rebaixar [@] 
╰─────────────────⪨

╭───∘⟬𝐀𝐋𝐄𝐀𝐓𝐎́𝐑𝐈𝐎⟭∘───⪨
│ঔৣ͜͡⪩${prefix}Criador
│ঔৣ͜͡⪩${prefix}Metadinha
│ঔৣ͜͡⪩${prefix}Memes
│ঔৣ͜͡⪩${prefix}Wallpaper
│ঔৣ͜͡⪩${prefix}Recados
│ঔৣ͜͡⪩${prefix}Imgpralink
╰─────────────────⪨

╭───∘⟬𝐃𝐎𝐖𝐍𝐋𝐎𝐀𝐃⟭∘───⪨
│ঔৣ͜͡⪩${prefix}Música [nome] 
│ঔৣ͜͡⪩${prefix}Vídeo [nome] 
│ঔৣ͜͡⪩${prefix}Tiktokmp4 [link] 
│ঔৣ͜͡⪩${prefix}Tiktokmp3 [link] 
│ঔৣ͜͡⪩${prefix}Soundcloud [link] 
╰─────────────────⪨

╭───∘⟬𝐃𝐈𝐕𝐄𝐑𝐒𝐀̃𝐎⟭∘───⪨
│ঔৣ͜͡⪩${prefix}Ppt [escolha]
│ঔৣ͜͡⪩${prefix}Chance [pergunta]
│ঔৣ͜͡⪩${prefix}Adivinhar [número]
│ঔৣ͜͡⪩${prefix}Escolher [opção]
╰─────────────────⪨

╭───∘⟬𝐅𝐈𝐆𝐔𝐑𝐈𝐍𝐇𝐀⟭∘───⪨
│ঔৣ͜͡⪩${prefix}Sticker 
│ঔৣ͜͡⪩${prefix}Attp1 [texto] 
│ঔৣ͜͡⪩${prefix}Attp2 [texto] 
│ঔৣ͜͡⪩${prefix}Attp3 [texto] 
│ঔৣ͜͡⪩${prefix}Attp4 [texto] 
│ঔৣ͜͡⪩${prefix}Attp5 [texto] 
│ঔৣ͜͡⪩${prefix}Attp6 [texto] 
│ঔৣ͜͡⪩${prefix}Attp7 [texto] 
╰─────────────────⪨

╭───∘⟬𝐌𝐎𝐃𝐈𝐅𝐈𝐂𝐀𝐑⟭∘───⪨
│ঔৣ͜͡⪩${prefix}Esquilo [áudio]
│ঔৣ͜͡⪩${prefix}Slowed [áudio]
│ঔৣ͜͡⪩${prefix}Grave [áudio]
│ঔৣ͜͡⪩${prefix}Estourar [áudio]
╰─────────────────⪨

╭───∘⟬𝐈𝐌𝐆-𝐀𝐍𝐈𝐌𝐄⟭∘───⪨
│ঔৣ͜͡⪩${prefix}Mikasa [image]
│ঔৣ͜͡⪩${prefix}Nezuko [image]
│ঔৣ͜͡⪩${prefix}Yumeko [image]
│ঔৣ͜͡⪩${prefix}Sasuke [image]
│ঔৣ͜͡⪩${prefix}Madara [image]
╰─────────────────⪨

╭───∘⟬𝐈𝐌𝐆-𝐋𝐎𝐆𝐎𝐒⟭∘───⪨
│ঔৣ͜͡⪩${prefix}angelwing [nome]
│ঔৣ͜͡⪩${prefix}hackneon [nome]
│ঔৣ͜͡⪩${prefix}ffavatar [nome]
│ঔৣ͜͡⪩${prefix}angelglx [nome]
│ঔৣ͜͡⪩${prefix}Logogame [nome]
╰─────────────────⪨
`
 }